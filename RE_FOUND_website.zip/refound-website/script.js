const $ = (s) => document.querySelector(s);
const grid = $("#reportGrid");
const STORAGE_KEY = "refound_reports_v1";
const demoReports = [
 {id:"demo1",type:"lost",name:"Botol minum biru",category:"Perlengkapan",color:"Biru muda",city:"Blitar",institution:"SMA Negeri 2 Blitar",location:"Perpustakaan",date:"2026-11-20",description:"Botol minum tertinggal setelah jam istirahat.",emoji:"🧴",status:"Dicari"},
 {id:"demo2",type:"found",name:"Tempat pensil",category:"Alat tulis",color:"Ungu",city:"Malang",institution:"Universitas Negeri Malang",location:"Gedung A, lantai 1",date:"2026-11-21",description:"Ditemukan di dekat ruang kelas. Diserahkan ke pos informasi.",emoji:"✏️",status:"Ditemukan"},
 {id:"demo3",type:"lost",name:"Kartu pelajar",category:"Dokumen",color:"Putih-biru",city:"Surabaya",institution:"SMA Negeri 5 Surabaya",location:"Lapangan sekolah",date:"2026-11-19",description:"Kartu pelajar kemungkinan terjatuh saat kegiatan olahraga.",emoji:"🪪",status:"Dicari"},
 {id:"demo4",type:"found",name:"Payung lipat",category:"Aksesori",color:"Kuning",city:"Blitar",institution:"Universitas Islam Balitar",location:"Kantin kampus",date:"2026-11-22",description:"Ditemukan setelah hujan. Saat ini dititipkan ke petugas kampus.",emoji:"☂️",status:"Ditemukan"},
 {id:"demo5",type:"lost",name:"Earphone putih",category:"Elektronik",color:"Putih",city:"Yogyakarta",institution:"Universitas Gadjah Mada",location:"Area perpustakaan",date:"2026-11-18",description:"Kotak earphone kecil warna putih, terakhir terlihat saat belajar.",emoji:"🎧",status:"Dicari"},
 {id:"demo6",type:"found",name:"Buku catatan",category:"Alat tulis",color:"Cokelat",city:"Malang",institution:"SMA Negeri 3 Malang",location:"Aula sekolah",date:"2026-11-20",description:"Buku catatan ditemukan setelah acara sekolah.",emoji:"📒",status:"Ditemukan"}
];
let reports = loadReports();
function loadReports(){try{const saved=JSON.parse(localStorage.getItem(STORAGE_KEY));return Array.isArray(saved)?saved:demoReports.slice()}catch{return demoReports.slice()}}
function saveReports(){localStorage.setItem(STORAGE_KEY,JSON.stringify(reports))}
function escapeHTML(value=""){return String(value).replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]))}
function formatDate(date){if(!date)return "Tanggal tidak tersedia";return new Date(date+"T00:00:00").toLocaleDateString("id-ID",{day:"numeric",month:"short",year:"numeric"})}
function render(){
 const query=$("#searchInput").value.trim().toLowerCase(),type=$("#typeFilter").value,category=$("#categoryFilter").value,city=$("#cityFilter").value;
 const filtered=reports.filter(r=>(type==="all"||r.type===type)&&(category==="all"||r.category===category)&&(city==="all"||r.city===city)&&[r.name,r.location,r.institution,r.city,r.color,r.description].join(" ").toLowerCase().includes(query));
 grid.innerHTML=filtered.map(r=>`<article class="report-card" data-id="${escapeHTML(r.id)}"><div class="report-photo" style="background:${r.type==="lost"?"#ffe8dc":"#e3f3e8"}">${r.photo?`<img src="${r.photo}" alt="${escapeHTML(r.name)}">`:`<span>${r.emoji||"📦"}</span>`}<span class="type-pill ${r.type}">${r.type==="lost"?"DICARI":"DITEMUKAN"}</span></div><div class="card-body"><div class="card-meta"><span>${escapeHTML(r.category)}</span><span>${formatDate(r.date)}</span></div><h3>${escapeHTML(r.name)}</h3><p>📍 ${escapeHTML(r.location)} · ${escapeHTML(r.city)}</p><div class="card-bottom"><span>${escapeHTML(r.institution)}</span><span>Lihat detail ↗</span></div></div></article>`).join("");
 $("#resultCount").textContent=`${filtered.length} laporan`;
 $("#emptyState").classList.toggle("hidden",filtered.length>0);
 $("#totalReports").textContent=reports.length;
 $("#lostCount").textContent=reports.filter(r=>r.type==="lost").length;
 $("#foundCount").textContent=reports.filter(r=>r.type==="found").length;
 $("#returnedCount").textContent=reports.filter(r=>r.status==="Dikembalikan").length;
 const cities=[...new Set(reports.map(r=>r.city).filter(Boolean))].sort(),select=$("#cityFilter"),current=select.value;
 select.innerHTML='<option value="all">Semua kota</option>'+cities.map(c=>`<option>${escapeHTML(c)}</option>`).join("");
 select.value=cities.includes(current)?current:"all";
}
function toast(message){const el=$("#toast");el.textContent=message;el.classList.add("show");setTimeout(()=>el.classList.remove("show"),2600)}
const reportDialog=$("#reportDialog");
document.querySelectorAll("[data-open-report]").forEach(b=>b.addEventListener("click",()=>reportDialog.showModal()));
$("#closeDialog").onclick=()=>reportDialog.close();$("#cancelDialog").onclick=()=>reportDialog.close();
$("#reportForm").addEventListener("submit",async e=>{
 e.preventDefault();const form=e.currentTarget,data=new FormData(form),file=data.get("photo");let photo="";
 if(file&&file.size){if(file.size>1500000){toast("Ukuran foto maksimal 1,5 MB.");return}photo=await resizeImage(file)}
 const report={id:"r"+Date.now(),type:data.get("type"),name:data.get("name").trim(),category:data.get("category"),color:data.get("color").trim(),city:data.get("city").trim(),institution:data.get("institution").trim(),location:data.get("location").trim(),date:data.get("date"),description:data.get("description").trim(),photo,emoji:emojiFor(data.get("category")),status:data.get("type")==="lost"?"Dicari":"Ditemukan"};
 reports.unshift(report);try{saveReports()}catch{reports.shift();toast("Penyimpanan penuh. Coba gunakan foto lebih kecil.");return}
 form.reset();reportDialog.close();render();toast("Laporan berhasil ditambahkan di perangkat ini!");$("#jelajahi").scrollIntoView({behavior:"smooth"});
});
function resizeImage(file){return new Promise(resolve=>{const reader=new FileReader();reader.onload=()=>{const img=new Image();img.onload=()=>{const canvas=document.createElement("canvas"),scale=Math.min(1,700/Math.max(img.width,img.height));canvas.width=img.width*scale;canvas.height=img.height*scale;canvas.getContext("2d").drawImage(img,0,0,canvas.width,canvas.height);resolve(canvas.toDataURL("image/jpeg",.65))};img.src=reader.result};reader.readAsDataURL(file)})}
function emojiFor(c){return {"Elektronik":"🎧","Alat tulis":"✏️","Aksesori":"🧢","Dokumen":"🪪","Perlengkapan":"🎒","Lainnya":"📦"}[c]||"📦"}
["#searchInput","#typeFilter","#categoryFilter","#cityFilter"].forEach(s=>$(s).addEventListener(s==="#searchInput"?"input":"change",render));
$("#resetFilters").onclick=()=>{$("#searchInput").value="";$("#typeFilter").value="all";$("#categoryFilter").value="all";$("#cityFilter").value="all";render()};
grid.addEventListener("click",e=>{const card=e.target.closest(".report-card");if(card)showDetail(card.dataset.id)});
function showDetail(id){const r=reports.find(x=>x.id===id);if(!r)return;$("#detailContent").innerHTML=`<div class="modal-head"><div class="eyebrow">REPORT DETAILS</div><button class="close-button" onclick="document.querySelector('#detailDialog').close()">×</button></div><div class="detail-photo" style="background:${r.type==="lost"?"#ffe8dc":"#e3f3e8"}">${r.photo?`<img src="${r.photo}" alt="${escapeHTML(r.name)}">`:r.emoji||"📦"}</div><p class="eyebrow" style="margin-top:20px">${r.type==="lost"?"BARANG HILANG":"BARANG DITEMUKAN"} · ${escapeHTML(r.category)}</p><h2>${escapeHTML(r.name)}</h2><p style="color:#777;font-size:13px;line-height:1.6">${escapeHTML(r.description||"Tidak ada deskripsi tambahan.")}</p><div class="detail-info"><div><small>Institusi</small><b>${escapeHTML(r.institution)}</b></div><div><small>Kota</small><b>${escapeHTML(r.city)}</b></div><div><small>Lokasi</small><b>${escapeHTML(r.location)}</b></div><div><small>Tanggal</small><b>${formatDate(r.date)}</b></div><div><small>Warna / ciri</small><b>${escapeHTML(r.color||"Tidak disebutkan")}</b></div><div><small>Status</small><b>${escapeHTML(r.status)}</b></div></div><div class="form-note">Untuk keamanan, lakukan verifikasi ciri khusus dan atur pengambilan melalui pihak sekolah/kampus atau titik temu aman.</div><div class="modal-actions"><button class="button button-light" onclick="document.querySelector('#detailDialog').close()">Tutup</button>${r.status!=="Dikembalikan"?`<button class="button button-dark" onclick="markReturned('${r.id}')">Tandai dikembalikan ✓</button>`:""}</div>`;$("#detailDialog").showModal()}
window.markReturned=id=>{const r=reports.find(x=>x.id===id);if(r){r.status="Dikembalikan";saveReports();$("#detailDialog").close();render();toast("Status laporan diperbarui.")}};
$("#matchButton").onclick=()=>{
 const lost=reports.filter(r=>r.type==="lost"),found=reports.filter(r=>r.type==="found"),pairs=[];
 lost.forEach(l=>found.forEach(f=>{let score=0;if(l.category===f.category)score+=3;if(l.color&&f.color&&l.color.toLowerCase()===f.color.toLowerCase())score+=2;if(l.city.toLowerCase()===f.city.toLowerCase())score+=2;if(l.institution.toLowerCase()===f.institution.toLowerCase())score+=3;if(l.name.toLowerCase().split(" ").some(w=>w.length>3&&f.name.toLowerCase().includes(w)))score+=2;if(score>=4)pairs.push({l,f,score})}));
 pairs.sort((a,b)=>b.score-a.score);
 $("#matchContent").innerHTML=`<div class="modal-head"><div><div class="eyebrow">SMART MATCH</div><h2>Kemungkinan kecocokan ✨</h2></div><button class="close-button" onclick="document.querySelector('#matchDialog').close()">×</button></div>${pairs.length?pairs.slice(0,8).map(p=>`<div class="match-result"><div><small>BARANG HILANG</small><b>${escapeHTML(p.l.name)}</b><span>${escapeHTML(p.l.institution)} · ${escapeHTML(p.l.city)}</span></div><div class="match-arrow">↔</div><div><small>BARANG DITEMUKAN</small><b>${escapeHTML(p.f.name)}</b><span>${escapeHTML(p.f.institution)} · ${escapeHTML(p.f.city)}</span></div></div>`).join(""):'<div class="empty-state"><div>🧩</div><h3>Belum ada kecocokan</h3><p>Tambahkan laporan kehilangan dan penemuan dengan detail yang sesuai.</p></div>'}<p class="match-disclaimer">Hasil ini hanya rekomendasi berdasarkan kemiripan data, bukan bukti bahwa barang tersebut pasti sama. Tetap lakukan verifikasi.</p>`;$("#matchDialog").showModal();
};
$("#menuToggle").onclick=()=>$(".desktop-nav").classList.toggle("open");
document.querySelectorAll(".desktop-nav a").forEach(a=>a.addEventListener("click",()=>$(".desktop-nav").classList.remove("open")));
render();
