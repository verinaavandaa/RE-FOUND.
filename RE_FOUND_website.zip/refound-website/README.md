# RE:FOUND — Lost & Found Community

Website demo untuk membantu siswa dan mahasiswa melaporkan barang hilang atau ditemukan.

## Fitur demo
- Beranda responsif dengan gaya colorful, creative, playful.
- Contoh laporan barang hilang dan ditemukan.
- Pencarian dan filter berdasarkan jenis, kategori, serta kota.
- Form untuk menambahkan laporan beserta foto.
- Smart Match sederhana berdasarkan kemiripan data.
- Detail laporan dan pembaruan status pengembalian.
- Statistik laporan.
- Data tersimpan di `localStorage` browser.

## Cara menjalankan
1. Ekstrak ZIP.
2. Buka folder `refound-website`.
3. Klik dua kali `index.html` atau buka dengan browser.
4. Coba tambah laporan dan gunakan pencarian / Smart Match.

## Cara mengunggah ke GitHub Pages
1. Login ke GitHub dan buat repository baru, misalnya `refound`.
2. Pilih **Public** dan buat repository.
3. Klik **Add file → Upload files**.
4. Unggah `index.html`, `style.css`, `script.js`, dan `README.md` (isi folder, bukan folder ZIP).
5. Klik **Commit changes**.
6. Buka **Settings → Pages**.
7. Pada **Build and deployment**, pilih **Deploy from a branch**.
8. Pilih branch `main`, folder `/ (root)`, lalu **Save**.
9. Tunggu proses publikasi. URL website akan muncul di halaman GitHub Pages.

## Catatan penting
Ini adalah prototype front-end. Data laporan hanya tersimpan pada browser/perangkat yang digunakan, belum dapat dibagikan lintas perangkat. Untuk penggunaan nasional sungguhan, hubungkan ke database online seperti Firebase, aktifkan login, atur aturan keamanan, dan gunakan penyimpanan foto online. Statistik demo juga berasal dari data contoh dan laporan lokal.
